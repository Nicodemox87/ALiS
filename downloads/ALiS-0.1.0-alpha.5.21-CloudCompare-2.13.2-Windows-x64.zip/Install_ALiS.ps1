#Requires -RunAsAdministrator
param([string]$CloudCompareDir = "$env:ProgramFiles\CloudCompare")
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
if(Get-Process CloudCompare -ErrorAction SilentlyContinue){throw 'Save your work and close CloudCompare before updating.'}
$hostExe = Join-Path $CloudCompareDir 'CloudCompare.exe'
if(!(Test-Path -LiteralPath $hostExe) -or !(Test-Path -LiteralPath (Join-Path $CloudCompareDir 'Qt5Core.dll'))){throw 'Select an existing CloudCompare 2.13.2 x64 / Qt5 installation.'}
$changelog = Join-Path $CloudCompareDir 'CHANGELOG.md'
if(!(Test-Path -LiteralPath $changelog) -or !((Get-Content -LiteralPath $changelog -TotalCount 9) -match '^v2\.13\.2(?:\s|$)')){throw 'CloudCompare CHANGELOG must identify v2.13.2 stable in its first nine lines.'}
$pe = [IO.File]::ReadAllBytes($hostExe)
$peOffset = [BitConverter]::ToInt32($pe,60)
if([BitConverter]::ToUInt16($pe,$peOffset+4) -ne 0x8664){throw 'CloudCompare must be x64.'}
$manifest = Get-Content -LiteralPath (Join-Path $root 'PAYLOAD_SHA256.json') -Raw | ConvertFrom-Json
$payload = [IO.Path]::GetFullPath((Join-Path $root 'payload'))
$targetRoot = [IO.Path]::GetFullPath($CloudCompareDir)
$entries = @()
foreach($item in $manifest){
    $relative = $item.path.Replace('/', [IO.Path]::DirectorySeparatorChar)
    $source = [IO.Path]::GetFullPath((Join-Path $payload $relative))
    $target = [IO.Path]::GetFullPath((Join-Path $targetRoot $relative))
    if(!$source.StartsWith($payload+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase) -or !$target.StartsWith($targetRoot+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'Unsafe payload path'}
    if((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant() -ne $item.sha256){throw "Payload checksum mismatch: $relative"}
    $entries += @{Relative=$relative;Source=$source;Target=$target;Expected=$item.sha256;Existed=(Test-Path -LiteralPath $target)}
}
$backup = Join-Path $targetRoot ('ALiS-Backups\before-alpha.5.21-'+[DateTime]::Now.ToString('yyyyMMdd-HHmmss')+'-'+[Guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $backup | Out-Null
# Back up every existing target before making the first replacement.
foreach($item in $entries){if($item.Existed){$saved=Join-Path $backup $item.Relative;New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($saved)) -Force | Out-Null;Copy-Item -LiteralPath $item.Target -Destination $saved}}
$changed = @()
try {
    foreach($item in $entries){
        $changed += $item
        New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($item.Target)) -Force | Out-Null
        Copy-Item -LiteralPath $item.Source -Destination $item.Target -Force
        if((Get-FileHash -LiteralPath $item.Target).Hash.ToLowerInvariant() -ne $item.Expected){throw "Installed checksum mismatch: $($item.Relative)"}
    }
} catch {
    foreach($item in $changed){if($item.Existed){Copy-Item -LiteralPath (Join-Path $backup $item.Relative) -Destination $item.Target -Force}else{if(Test-Path -LiteralPath $item.Target){Remove-Item -LiteralPath $item.Target -Force}}}
    throw
}
Write-Host "ALiS alpha.5.21 installed and verified. Backup: $backup" -ForegroundColor Green
Write-Host 'Reopen CloudCompare and your saved BIN project. No survey file or model was changed.'
Read-Host 'Press Enter to close'
